public class Employe implements IAffiche{
    //Attributs d'instance
    private int id;
    private String nomComplet;
    private String dateEmbauche;

    //Attribut statique
    private static int nbEmp;
    private static int date;
    //date==2021; ????

    //Constructeurs par defaut
    public Employe(){
        nbEmp++;
        id=nbEmp;
    }

    //Constructeur surchargé
    public Employe(int id, String nomComplet, String dateEmbauche){
        nbEmp++;
        id=nbEmp;
        setId(id);
        setNomComplet(nomComplet);
        setDateEmbauche(dateEmbauche);
    }

    public Employe(String nomComplet, String dateEmbauche){
        nbEmp++;
        id=nbEmp;
        setNomComplet(nomComplet);
        setDateEmbauche(dateEmbauche);
    }

    //Getters
    public int getId(){
        return id;
    }

    public String getNomComplet(){
        return nomComplet;
    }
    public String getDateEmbauche(){
        return dateEmbauche;
    }

    public static int getNbEmp(){
        return nbEmp;
    }

    //Setters
    public void setId(int id){
        this.id=id;
    }
    public void setNomComplet(String nomComplet){
        this.nomComplet=nomComplet;
    }
    public void setDateEmbauche(String dateEmbauche){
        this.dateEmbauche=dateEmbauche;
    }
    public static void setNbEmp(int nbEmp){
        Employe.nbEmp=nbEmp;
    }

    //Metiers
    /*/public int anciennete(){
        return date-dateEmbauche;
    }/*/
    @Override
    public void affiche(){
        System.out.println("Id: "+id+"\nNom Complet: "+nomComplet+"\nNombre d'employes': "+nbEmp);
    }
}