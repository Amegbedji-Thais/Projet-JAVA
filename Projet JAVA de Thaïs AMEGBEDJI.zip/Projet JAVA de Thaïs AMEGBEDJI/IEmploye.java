public interface IAffiche{
    public void affiche();
}
public interface ICompare{
    public void compare();
    
}