public class Serv{
    private final int TAILLE=10;
    private int nbSer; 
    private Service[] tabService= new Service[TAILLE];
    
    private Employe[] tabEmploye= new Employe[TAILLE];
    private int nbEmp;
    
    public void ajouterService(Service s){
        if(nbSer<TAILLE){
            tabService[nbSer]=s;
            nbSer++;
        }
        else{
            System.out.println("Le tableau est plein");
        }
        
    }

    public void listerService(){
        for(Service s:tabService){
            if(s!=null){
                s.affiche();
            }
        }
    }

    public void ajouterEmploye(Employe e){
        if(nbEmp<TAILLE){
            tabEmploye[nbEmp]=e;
            nbEmp++;
        }
        else{
            System.out.println("Le tableau est plein");
        }
        
    }

    public void listerEmploye(){
        for(Employe e:tabEmploye){
            if(e!=null){
                if(e instanceof Employe){
                    e.affiche();
                }
            }
        }
    }
}