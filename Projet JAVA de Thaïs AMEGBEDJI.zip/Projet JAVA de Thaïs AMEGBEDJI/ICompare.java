public interface ICompare{
    public void compare();
    
}