public interface IAffiche{
    public void affiche();
}