class Service implements IAffiche{
    //Attributs d'instance
    private int id;
    private String libelle;

    //Attributs statiques
    private static int nbSer;

    //Constructeurs
    
        public Service(){
            nbSer++;
            id=nbSer;
        }

        public Service(int id, String libelle){
            nbSer++;
            id=nbSer;
            this.setId(id);
            this.setLibelle(libelle);
    }

    //Getters
    public int getId(){
        return id;
    }
    public String getLibelle(){
        return libelle;
    }
    
    //Setters 
    public void setId(int id){
        if(id>0){
            this.id=id;
        }
    }
    public void setLibelle(String libelle){
        if(libelle.compareTo("")!=0){
            this.libelle=libelle;
        }
    }

    //Métiers
    @Override
    public void affiche(){
        System.out.println("Id: "+id+" \nLibelle: "+libelle);
    } 


}