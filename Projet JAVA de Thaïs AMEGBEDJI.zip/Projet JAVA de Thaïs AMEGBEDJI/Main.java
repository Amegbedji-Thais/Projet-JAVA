import java.util.Scanner;
public class Main{
    private static Scanner scanner=new Scanner(System.in);
    public static void main(String[] args) {
        int choix;
        Serv se=new Serv();
        do {
            choix=menu();
            switch (choix) {
                case 1:
                    System.out.println("Entrez le libelle : ");
                    String libelle=scanner.nextLine();
                    Service s=new Service();
                    s.setLibelle(libelle); 
                    se.ajouterService(s);
                    break;

                case 2:
                    se.listerService();
                    break;

                case 3:
                    System.out.println("Entrez le nom et le prenom : ");
                    String nomComplet=scanner.nextLine();
                    System.out.println("Entrez la date d'embauche : ");
                    String dateEmbauche=scanner.nextLine();
                    Employe e=new Employe(nomComplet, dateEmbauche);
                    se.ajouterEmploye(e);               
                    break;

                case 4:
                    se.listerEmploye();
                    break;
                    
                case 5:
                    System.out.println("Au revoir");
                    break;
                   
                default:
                    System.out.println("Veuillez faire un bon choix");
                    break;
            }

        }
        while(choix!=5);
    }

    public static int menu(){
        System.out.println("1-Ajouter service"
                            +"\n2-Lister service"
                            +"\n3-Ajouter employe"
                            +"\n4-Lister employes"
                            +"\n5-Quitter"
                            +"\nFaites votre choix : ");
        String choix;
        
        choix=scanner.nextLine();
        return Integer.parseInt(choix);
    }
}